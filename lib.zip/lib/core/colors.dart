import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFF0A0F14);
  static const Color surface = Color(0xFF131B23);
  static const Color accentCyan = Color(0xFF00E5FF);
  static const Color accentTeal = Color(0xFF00BFA5);
  static const Color textMain = Colors.white;
  static const Color textSecondary = Color(0xFF94A3B8);
  static const Color cardGlow = Color(0xFF00E5FF);
  static const Color cardBorder = Color(0xFF1E293B);

  static const Color brandDark = Color(0xFF0F172A);
  static const Color overlayTop = Color(0x99000000);
  static const Color overlayBottom = Color(0x66000000);
  static const Color gradientBlue = Color(0xFF2196F3);
  static const Color gradientGreen = Color(0xFF00E676);
  static const Color brandBlueLight = Color(0xFF64B5F6);
}
