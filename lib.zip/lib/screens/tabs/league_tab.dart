import 'package:flutter/material.dart';
import '../../core/colors.dart';
import '../../core/constants.dart';
import '../../core/responsive_helper.dart';

class LeagueTab extends StatefulWidget {
  const LeagueTab({super.key});

  @override
  State<LeagueTab> createState() => _LeagueTabState();
}

class _LeagueTabState extends State<LeagueTab> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final bool _isOnline = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
      ),
      child: Column(
        children: [
          _buildHeader(),
          _buildTierCard(),
          SizedBox(height: 20.h),
          _buildModeSelector(),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildLeaguesContent(isOnline: false),
                _buildLeaguesContent(isOnline: true),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.all(20.w),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("LEAGUE", style: AppTextStyles.heading),
              Text("PROGRESSION", style: AppTextStyles.heading.copyWith(color: AppColors.accentCyan)),
            ],
          ),
          Container(
            padding: EdgeInsets.all(10.w),
            decoration: BoxDecoration(
              color: AppColors.surface,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white10),
            ),
            child: Icon(Icons.emoji_events, color: const Color(0xFFD4AF37), size: 24.w),
          ),
        ],
      ),
    );
  }

  Widget _buildTierCard() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w),
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF1E293B), Color(0xFF0F172A)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24.w),
        border: Border.all(color: Colors.white10),
        boxShadow: [
          BoxShadow(
            color: AppColors.accentCyan.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 60.w,
                height: 60.w,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.05),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Icon(Icons.shield, color: AppColors.accentCyan, size: 35.w),
                ),
              ),
              SizedBox(width: 16.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "PRO LEAGUE TIER",
                      style: TextStyle(
                        color: Colors.white54,
                        fontSize: 10.sp,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      "BRONZE DIVISION II",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text("RANK", style: TextStyle(color: Colors.white38, fontSize: 10.sp)),
                  Text("#425", style: TextStyle(color: AppColors.accentCyan, fontSize: 16.sp, fontWeight: FontWeight.bold)),
                ],
              ),
            ],
          ),
          SizedBox(height: 20.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text("850 / 1000 XP", style: TextStyle(color: Colors.white70, fontSize: 12.sp, fontWeight: FontWeight.w600)),
              Text("SILVER TIER", style: TextStyle(color: Colors.white38, fontSize: 10.sp, fontWeight: FontWeight.bold)),
            ],
          ),
          SizedBox(height: 8.h),
          ClipRRect(
            borderRadius: BorderRadius.circular(4.h),
            child: LinearProgressIndicator(
              value: 0.85,
              backgroundColor: Colors.white12,
              valueColor: const AlwaysStoppedAnimation<Color>(AppColors.accentCyan),
              minHeight: 8.h,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20.w),
      height: 48.h,
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12.h),
        border: Border.all(color: Colors.white10),
      ),
      child: TabBar(
        controller: _tabController,
        indicator: BoxDecoration(
          color: AppColors.accentCyan,
          borderRadius: BorderRadius.circular(10.h),
        ),
        labelColor: Colors.black87,
        unselectedLabelColor: Colors.white70,
        labelStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 13.sp),
        tabs: const [
          Tab(text: "OFFLINE LEAGUE"),
          Tab(text: "ONLINE LEAGUE"),
        ],
      ),
    );
  }

  Widget _buildLeaguesContent({required bool isOnline}) {
    return ListView(
      padding: EdgeInsets.all(20.w),
      children: [
        _buildSectionHeader(isOnline ? "TOP GLOBAL MANAGERS" : "REGIONAL STANDINGS"),
        SizedBox(height: 12.h),
        _buildStandingsList(),
        SizedBox(height: 24.h),
        _buildSectionHeader("TROPHY COLLECTION"),
        SizedBox(height: 12.h),
        _buildTrophyRow(),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    return Row(
      children: [
        Container(
          width: 4.w,
          height: 16.h,
          decoration: BoxDecoration(
            color: AppColors.accentCyan,
            borderRadius: BorderRadius.circular(2.w),
          ),
        ),
        SizedBox(width: 8.w),
        Text(
          title,
          style: TextStyle(
            color: Colors.white70,
            fontSize: 12.sp,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  Widget _buildStandingsList() {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16.w),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        children: [
          _buildStandingRow(rank: "1", team: "CYBER TITANS", record: "12-0", isHighlighted: false),
          _buildStandingRow(rank: "2", team: "NEON KNIGHTS", record: "10-2", isHighlighted: false),
          _buildStandingRow(rank: "3", team: "DYNASTY WARRIORS", record: "10-2", isHighlighted: false),
          _buildStandingRow(rank: "4", team: "GRIDIRON KINGS", record: "9-3", isHighlighted: true),
          _buildStandingRow(rank: "5", team: "SHADOW RAIDERS", record: "8-4", isHighlighted: false, isLast: true),
        ],
      ),
    );
  }

  Widget _buildStandingRow({
    required String rank,
    required String team,
    required String record,
    required bool isHighlighted,
    bool isLast = false,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: isHighlighted ? AppColors.accentCyan.withOpacity(0.1) : Colors.transparent,
        border: isLast ? null : Border(bottom: BorderSide(color: Colors.white.withOpacity(0.05))),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 25.w,
            child: Text(
              rank,
              style: TextStyle(
                color: isHighlighted ? AppColors.accentCyan : Colors.white38,
                fontWeight: FontWeight.bold,
                fontSize: 13.sp,
              ),
            ),
          ),
          Expanded(
            child: Text(
              team,
              style: TextStyle(
                color: isHighlighted ? Colors.white : Colors.white70,
                fontWeight: isHighlighted ? FontWeight.bold : FontWeight.normal,
                fontSize: 13.sp,
              ),
            ),
          ),
          Text(
            record,
            style: TextStyle(
              color: isHighlighted ? AppColors.accentCyan : Colors.white54,
              fontWeight: FontWeight.bold,
              fontSize: 13.sp,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTrophyRow() {
    return Row(
      children: [
        _buildTrophyItem(Icons.emoji_events, "CHAMPION", "2025"),
        SizedBox(width: 12.w),
        _buildTrophyItem(Icons.military_tech, "MVP", "2024"),
        SizedBox(width: 12.w),
        _buildTrophyItem(Icons.stars, "ALL-STAR", "2024"),
        SizedBox(width: 12.w),
        _buildTrophyItem(Icons.workspace_premium, "LEGEND", "2023"),
      ],
    );
  }

  Widget _buildTrophyItem(IconData icon, String label, String year) {
    return Expanded(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 12.h),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(16.w),
          border: Border.all(color: Colors.white10),
        ),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFFD4AF37), size: 24.w),
            SizedBox(height: 8.h),
            Text(label, style: TextStyle(color: Colors.white70, fontSize: 8.sp, fontWeight: FontWeight.bold)),
            Text(year, style: TextStyle(color: Colors.white24, fontSize: 8.sp)),
          ],
        ),
      ),
    );
  }
}
