import 'package:flutter/material.dart';
import '../../core/colors.dart';
import '../../core/constants.dart';
import '../../core/responsive_helper.dart';
import '../profile_screen.dart';

class HomeTab extends StatelessWidget {
  const HomeTab({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Background Stadium Image
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 350.h,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.asset(
                    'assets/images/signup_background.png', // Switched to a more dynamic background
                    fit: BoxFit.cover,
                    alignment: Alignment.topCenter,
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.black.withOpacity(0.6),
                          AppColors.background.withOpacity(0.9),
                          AppColors.background,
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Content
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: [
                   _buildTopBar(),
                   SizedBox(height: 10.h),
                   _buildTeamHeader(),
                   SizedBox(height: 20.h),
                   _buildOverallStatsCircle(),
                   SizedBox(height: 25.h),
                   _buildActionButtons(context),
                   SizedBox(height: 20.h),
                   _buildRosterSection(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 24.w, vertical: 8.h),
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 10.h),
      decoration: BoxDecoration(
        color: const Color(0xFF1A242D).withOpacity(0.8),
        borderRadius: BorderRadius.circular(16.h),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _buildTopBarItem("GAMETIME:", "02:14:55", AppColors.accentCyan),
          Container(
            height: 20.h,
            width: 1,
            color: Colors.white24,
            margin: EdgeInsets.symmetric(horizontal: 12.w),
          ),
          _buildTopBarItem("DRAFT DAY:", "06d 14h 30m", const Color(0xFFFFB74D)),
        ],
      ),
    );
  }

  Widget _buildTopBarItem(String label, String value, Color valueColor) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          label,
          style: TextStyle(
            color: Colors.white54,
            fontSize: 10.sp,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(width: 6.w),
        Text(
          value,
          style: TextStyle(
            color: valueColor,
            fontSize: 11.sp,
            fontWeight: FontWeight.w900,
            fontFamily: 'Courier',
          ),
        ),
      ],
    );
  }

  Widget _buildTeamHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 24.w),
      child: Row(
        children: [
           // Lion Logo (Placeholder Icon)
           Container(
             width: 60.w,
             height: 60.w,
             decoration: const BoxDecoration(
               shape: BoxShape.circle,
               color: Color(0xFF131B23),
               boxShadow: [
                 BoxShadow(color: Colors.black45, blurRadius: 10, offset: Offset(0, 4)),
               ],
             ),
             child: Icon(Icons.catching_pokemon, color: const Color(0xFFD4AF37), size: 40.w), // Lion substitute
           ),
           SizedBox(width: 16.w),
           Expanded(
             child: Column(
               crossAxisAlignment: CrossAxisAlignment.start,
               children: [
                 Row(
                   children: [
                     Text(
                       "GRIDIRON KINGS",
                       style: TextStyle(
                         color: Colors.white,
                         fontSize: 20.sp,
                         fontWeight: FontWeight.w900,
                         letterSpacing: 1.2,
                       ),
                     ),
                     SizedBox(width: 8.w),
                     Icon(Icons.edit_outlined, color: Colors.white38, size: 16.w),
                   ],
                 ),
                 SizedBox(height: 4.h),
                 Row(
                   children: [
                     Text(
                       "RECORD: ",
                       style: TextStyle(color: Colors.white38, fontSize: 11.sp),
                     ),
                     Text(
                       "3-7",
                       style: TextStyle(color: Colors.white70, fontSize: 11.sp, fontWeight: FontWeight.bold),
                     ),
                     Text(
                       "  |  LEAGUE RANK: ",
                       style: TextStyle(color: Colors.white38, fontSize: 11.sp),
                     ),
                     Text(
                       "9th (4 GB)",
                       style: TextStyle(color: Colors.white70, fontSize: 11.sp, fontWeight: FontWeight.bold),
                     ),
                   ],
                 ),
               ],
             ),
           ),
        ],
      ),
    );
  }

  Widget _buildOverallStatsCircle() {
    return Container(
      width: 140.w,
      height: 140.w,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: const Color(0xFF8D6E63), width: 8.w),
        gradient: const RadialGradient(
          colors: [
             Color(0xFF3E2723),
             Color(0xFF1A1A1A),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFFD4AF37).withOpacity(0.3),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            "OVERALL\nTEAM SPS:",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white70,
              fontSize: 9.sp,
              fontWeight: FontWeight.bold,
              height: 1.1,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            "68.5",
            style: TextStyle(
              color: Colors.white,
              fontSize: 28.sp,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: EdgeInsets.symmetric(horizontal: 20.w),
      child: Row(
        children: [
          _buildActionButton("TRAIN\nPLAYERS", const [Color(0xFF2196F3), Color(0xFF1976D2)], Icons.fitness_center, context),
          _buildActionButton("SCOUT\nPLAYERS", const [Color(0xFF43A047), Color(0xFF2E7D32)], Icons.search, context),
          _buildActionButton("VIEW\nMATCHUP", const [Color(0xFF9C27B0), Color(0xFF7B1FA2)], Icons.vignette, context),
          _buildActionButton("VIEW\nROSTER", const [Color(0xFFEF6C00), Color(0xFFE64A19)], Icons.groups, context),
        ],
      ),
    );
  }

  Widget _buildActionButton(String label, List<Color> colors, IconData icon, BuildContext context) {
    return GestureDetector(
      onTap: () {
        if (label.startsWith("TRAIN")) {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfileScreen(playerName: "Gridiron Kings")));
        }
      },
      child: Container(
        width: 85.w,
        height: 44.h,
        margin: EdgeInsets.symmetric(horizontal: 4.w),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: colors),
          borderRadius: BorderRadius.circular(12.h),
        ),
        child: Center(
          child: Text(
            label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 9.sp,
              fontWeight: FontWeight.w900,
              height: 1.1,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildRosterSection(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFF0F1720),
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(24),
          topRight: Radius.circular(24),
        ),
      ),
      child: Column(
        children: [
          _buildRosterHeader(),
          _buildPlayerRow(pos: "QB", name: "J. Fields", sps: "78", matchup: "@LAR", exp: "4Y", img: Icons.person, context: context),
          _buildPlayerRow(pos: "RB", name: "S. Barkley", sps: "88", matchup: "vs DAL", exp: "6Y", img: Icons.person, context: context),
          _buildPlayerRow(pos: "RB", name: "K. Walker", sps: "72", matchup: "@SEA", exp: "2Y", img: Icons.person, context: context),
          _buildPlayerRow(pos: "WR", name: "J. Chase", sps: "91", matchup: "@CIN", exp: "3Y", img: Icons.person, context: context),
          _buildPlayerRow(pos: "WR", name: "D. Smith", sps: "85", matchup: "vs PHI", exp: "3Y", img: Icons.person, context: context),
          _buildSectionHeader("BENCH (18)"),
          _buildPlayerRow(pos: "QB", name: "J. Fields", sps: "78", matchup: "@LAR", exp: "4Y", img: Icons.person, context: context),
          _buildSectionHeader("IR (4)"),
          _buildPlayerRow(pos: "IR", name: "S. Barkley", sps: "88", matchup: "vs DAL", exp: "6Y", img: Icons.person, context: context),
          _buildSectionHeader("TAXI (2)"),
          SizedBox(height: 50.h),
        ],
      ),
    );
  }

  Widget _buildRosterHeader() {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white10)),
      ),
      child: Row(
        children: [
          SizedBox(width: 35.w, child: Text("Pos", style: _headerStyle)),
          Expanded(child: Text("Player", style: _headerStyle)),
          SizedBox(width: 40.w, child: Text("SPS", style: _headerStyle)),
          SizedBox(width: 60.w, child: Text("Matchup", style: _headerStyle)),
          SizedBox(width: 35.w, child: Text("Exp.", style: _headerStyle)),
          SizedBox(width: 65.w, child: Center(child: Text("Train", style: _headerStyle))),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Container(
      width: double.infinity,
      color: Colors.black26,
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      child: Text(
        title,
        style: TextStyle(
          color: Colors.white38,
          fontSize: 10.sp,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildPlayerRow({
    required String pos,
    required String name,
    required String sps,
    required String matchup,
    required String exp,
    required IconData img,
    required BuildContext context,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 8.h),
      decoration: BoxDecoration(
        border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.05))),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 35.w,
            child: Text(
              pos,
              style: TextStyle(color: Colors.white38, fontSize: 11.sp, fontWeight: FontWeight.w600),
            ),
          ),
          Expanded(
            child: Row(
              children: [
                CircleAvatar(
                  radius: 14.w,
                  backgroundColor: Colors.white12,
                  child: Icon(img, size: 16.w, color: Colors.white54),
                ),
                SizedBox(width: 10.w),
                Text(
                  name,
                  style: TextStyle(color: Colors.white, fontSize: 11.sp, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 40.w,
            child: Text(
              sps,
              style: TextStyle(color: Colors.white, fontSize: 11.sp, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(
            width: 60.w,
            child: Text(
              matchup,
              style: TextStyle(color: Colors.white38, fontSize: 11.sp),
            ),
          ),
          SizedBox(
            width: 35.w,
            child: Text(
              exp,
              style: TextStyle(color: Colors.white38, fontSize: 11.sp),
            ),
          ),
          SizedBox(
            width: 65.w,
            child: GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfileScreen(playerName: name))),
              child: Container(
                height: 28.h,
                decoration: BoxDecoration(
                  color: const Color(0xFF1E293B),
                  borderRadius: BorderRadius.circular(8.h),
                  border: Border.all(color: Colors.white12),
                ),
                child: Center(
                  child: Text(
                    "Train",
                    style: TextStyle(color: Colors.white70, fontSize: 10.sp, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  TextStyle get _headerStyle => TextStyle(
    color: Colors.white24,
    fontSize: 10.sp,
    fontWeight: FontWeight.bold,
  );
}
